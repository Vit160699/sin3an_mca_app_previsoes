package usjt_ccp3anmca_observer;

public abstract class Display implements Observer{
	
	public abstract void display();
}
